<div class="container-fluid">
<div class="page-header">
    <div class="pull-left" >
        <h1 style="font-size:4vw;">Dashboard</h1>
    </div>
    <div class="pull-right">
        <ul class="stats" style="display: block !important;">
            <li class="lightred">
                <i class="icon-calendar"></i>
                <div class="details" >
                    <span class="big"></span>
                    <span></span>
                </div>
            </li>
        </ul>
    </div>
</div>
<div class="row-fluid">
<div class="span6">
<div class="box box-color box-bordered">
<div class="box-title">
<h3>
<i class="icon-book"></i>
<a href="main.php?g=reports&p=4" style="color: #fff;" >Reports List</a>
</h3>
</div>
</div>
</div>
<div class="span6">
<div class="box box-color box-bordered lightred">
<div class="box-title">
<h3>
<i class="icon-road"></i>
<a href="main.php?g=routing&p=5" style="color: #fff;">Routing List</a>
</h3>
</div>
</div>
</div>
</div>



<div class="row-fluid">
<div class="span6">
<div class="box box-color box-bordered green">
<div class="box-title">
<h3>
<i class="icon-plus-sign-alt"></i>
<a href="main.php?g=institutions&p=1" style="color: #fff;" >Institutions List</a>
</h3>
</div>
</div>
</div>
</div>

</div>