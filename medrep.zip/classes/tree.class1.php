<?php
class tree{
	private $taken = array();
	private $child = array();
	private $cache = array();
	public $array = array();
	private $path  = array();
	function __construct($c){
		if(!is_array($c)) $c = array();
		foreach($c as $row){
			if($row['id'] == 0) {
				$this->child['section_'.$row['pid']][] = 'section_'.$row['section_id'];
				$this->cache['section_'.$row['section_id']] = $row;
			} else {
				$this->child['section_'.$row['pid']][] = 'single_'.$row['id'];
				$this->cache['single_'.$row['id']] = $row;
			}
		}
		@ksort($this->child);
		$this->array = $this->build_array($this->child);
	}
	function untree(){
		$this->taken = array();
		$this->child = array();
		$this->cache = array();
		$this->array = array();
		$this->path  = array();
	}
	function build_array($in, $p = 0){
		$r = array();
		foreach ($in as $kgson => $gson){
			// HIGHEST PARENT
			if(is_array($gson)){
				if(!in_array($kgson, $this->taken)){
					$r[$kgson]['s'] = array('title' => 'TOP');
					$r[$kgson]['c'] = $this->build_array ($gson, $p);
					$this->taken[] = $kgson;
					$this->path[$kgson] = $p;
				}
			// OTHER PARENTS
			}else{
				if(!in_array($gson, $this->taken)){
					$r[$gson]['s'] = $this->cache[$gson];
					if(count($this->child[$gson]) > 0){
						$r[$gson]['c'] = $this->build_array ($this->child[$gson], $p.'-'.$gson);
					}
					$this->taken[] = $gson;
					$this->path[$gson] = $p.'-'.$gson;
				}
			}
		}
		return $r;
	}
	function build_select_list($in = array(), $pre = ''){
		global $s;
		if($pre == '') $s = array();
		while(list($k, $v) = each($in)) {
			if(strpos($k, 'ection')){
				$style = (strlen($pre) / 12 ) % 3 ;
				if($k != 'section_0'){$s[$v['s']['section_id']] = array('style' => "class=\"tree_select_".$style."\"",'pref' => $pre  ,'title' => $v['s']['title'], 'position' => $v['s']['position'] );}
				if(is_array($v['c'])){$this->build_select_list($v['c'], $pre . "&nbsp;&nbsp;");}
			}
		}
		return $s;
	}
	function build_path($id){
		$r = array();
		$p = array();
		if($this->path[$id]){
			$r = @explode('-', $this->path[$id]);
			foreach ($r as $v){
				if($v == '0') continue;
				$p[str_replace('section_', '', $v)] = $this->cache[$v]['title'];
			}
		}
		return $p;
	}
	function build_child($id){
		$r = array();
		$c = array();
		if($this->child['section_'.$id]){
			$r = $this->child['section_'.$id];
			foreach ($r as $v){
				if($this->cache[$v]['id'] == 0){
					$c[] = array('id' => $this->cache[$v]['section_id'], 'title' => $this->cache[$v]['title'], 'sons' => count($this->child['section_'.$this->cache[$v]['section_id']]), 'icon' => '', 'validate' => $this->cache[$v]['validate']);
				}
			}
		}
		return $c;
	}
	function build_navigation($id){
		$path = $this->build_path('section_'.$id);
		$child = $this->build_child($id);
		return array($path, $child);
	}
	function build_menu($in = array()) {
		$r = '';
		while ( list ( $k, $v ) = each ( $in ) ) {
			if (is_array ( $v ['c'] )) {
				$c = "<li id=\"" . $v ['s'] ['section_id'] . "\"><a " . $v ['s'] ['url'] . " class=\"dir " . $v ['s'] ['attr'] . "\"><span>" . $v ['s'] ['title'] . "</span></a>" . "\n<ul>\n" . $this->build_menu ( $v ['c'] ) . "</ul>\n</li>\n";
			} else {
				$c = "<li id=\"" . $v ['s'] ['section_id'] . "\"><a " . $v ['s'] ['url'] . " class=\"" . $v ['s'] ['attr'] . "\"><span>" . $v ['s'] ['title'] . "</span></a><ul></ul></li>\n";
			}
			$r .= $c;
		}
		return $r;
	}
}