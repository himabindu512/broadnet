<?php
/******************************************************************
  A Singleton database class that provides basic functionality for conneting to a \
  database and executing queries
 ******************************************************************/

//classe database

$config ['dbUser'] = 'broadmed_admin';
$config ['dbPass'] = '}l~}#F6{u{9w';
$config ['dbName'] = 'broadmed_db';
$config ['dbServer'] = 'localhost';

class QuickDB {
	
	var $_result;
	
	var $_host;
	
	var $_user;
	
	var $_pass;
	
	var $_database;
	
	var $_error;
	
	var $_connection;
	
	var $_sql;
	
	/** 
	Creates and Handles the connection to the databaese; this class is a singleton.
	 */
	
	function QuickDB() {
		global $config;
		
		$this->_host = $config ['dbServer'];
		$this->_user = $config ['dbUser'];
		$this->_pass = $config ['dbPass'];
		$this->_database = $config ['dbName'];
		$this->connect ();
	}
	
	/**
		Connects to the database using the already set parameters
	 */
	function connect() {
		$this->_connection = mysql_connect ( $this->_host, $this->_user, $this->_pass );
		
		mysql_select_db ( $this->_database, $this->_connection );
		mysql_query ( "SET CHARACTER SET 'utf8'", $this->_connection );
		return ($this->_connection);
	
	}
	
	function CloseDb() {
		return mysql_close ( $this->_connection );
	}
	
	function Execute($sql) {
		$this->_sql = $sql; //echo $sql.'<br />';
		$this->_result = mysql_query ( $sql, $this->_connection );
		
		if (! $this->_result) {
			$errorStr = $this->Error ();
			$errorStr .= '<br/>Query that caused the Error: <b>' . $this->LatestSql () . '</b>';
			die ( $errorStr );
			return false;
		}
		return $this->_result;
	} //end ExecuteQuery
	

	function LatestId() {
		return mysql_insert_id ();
	}
	
	function Affected() {
		return mysql_affected_rows ();
	}
	
	function DropDb($database) {
		return mysql_drop_db ( $database );
	}
	
	function NumRows() {
		return mysql_num_rows ( $this->_result );
	}
	
	/**
 returns the record set
	 */
	function Result() {
		return $this->_result;
	}
	
	function Error() {
		return mysql_error ();
	}
	
	function ErrorNum() {
		return mysql_errno ();
	}
	
	function LatestSql() {
		return $this->_sql;
	}
	
	function Load($query) {
		$set = array ();
		$this->Execute ( $query );
		
		while ( $row = mysql_fetch_array ( $this->_result ) ) {
			$set [] = $row;
		}
		
		return $set;
	}
	
	function LoadSingle($query) {
		$set = array ();
		$this->Execute ( $query );
		
		while ( $row = mysql_fetch_row ( $this->_result ) ) {
			$set [] = $row [0];
		}
		
		return $set;
	}
}
?>