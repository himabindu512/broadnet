<?php
class upload{
	private $upload_max_size = 50000000;
	private $path = '';
	private $input = array();
	private $lang = array();
	private $module = '';
	function __construct($module){
		$this->module = $module;
		$this->path = './';
		$this->input = $this->site_input();
		// upload_file
		$this->lang ['err_file_not_supported'] = "File Extension is not allowed";
		$this->lang ['err_file_max_size'] = "The file size exceeds the maximum allowable size";
		$this->lang ['err_file_upload_fail'] = "Error uploading file";
		// upload_image
		$this->lang ['err_image_not_supported'] = "Image Extension is not allowed";
		$this->lang ['err_image_max_size'] = "The image size exceeds the maximum allowable size";
		$this->lang ['err_image_upload_fail'] = "Error uploading image1";
		$this->lang ['err_image_upload_fail1'] = "Error uploading image0";
		$this->lang ['err_image_max_width'] = "The image width exceeds the maximum allowable width";
		$this->lang ['err_image_max_height'] = "The image height exceeds the maximum allowable height";
		$this->lang ['err_image_not_recognized'] = "File is not recognized as an image";
		if($this->input['action'] == 'upload'){
			$this->upload_all();
		}else if($this->input['action'] == 'unload'){
			$this->unload();
		}
	}
	// FILTERING $_POST AND $_GET DATA
	function site_input() {
		global $HTTP_GET_VARS, $HTTP_POST_VARS;
		$g_result = array ();
		$p_result = array ();
		if (! isset ( $HTTP_POST_VARS ) && isset ( $_POST )) {
			$HTTP_POST_VARS = $_POST;
			$HTTP_GET_VARS = $_GET;
		}
		if (is_array ( $HTTP_GET_VARS )) {
			$g_result = $this->site_input2 ( $HTTP_GET_VARS );
		}
		if (is_array ( $HTTP_POST_VARS )) {
			$p_result = $this->site_input2 ( $HTTP_POST_VARS );
		}
		return array_merge ( $g_result, $p_result );
	}
	function site_input2($input) {
		$result = array ();
		while ( list ( $k, $v ) = each ( $input ) ) {
			if (is_array ( $v )) {
				$v = $this->site_input2 ( $v );
			} else {
				$k = preg_replace ( "/\.\./", "", $k );
				$k = preg_replace ( "/\_\_(.+?)\_\_/", "", $k );
				$k = preg_replace ( "/^([\w\.\-\_]+)$/", "$1", $k );
				$v = str_replace ( "&", "&amp;", $v );
				$v = str_replace ( "<!--", "&#60;&#33;--", $v );
				$v = str_replace ( "-->", "--&#62;", $v );
				$v = preg_replace ( "/<script/i", "&#60;script", $v );
				$v = str_replace ( ">", "&gt;", $v );
				$v = str_replace ( "<", "&lt;", $v );
				$v = str_replace ( "\"", "&quot;", $v );
				//$v = preg_replace( "/\n/"        , "<br />"        , $v );
				$v = preg_replace ( "/\\\$/", "&#036;", $v );
				$v = preg_replace ( "/\r/", "", $v );
				$v = str_replace ( "!", "&#33;", $v );
				$v = str_replace ( "'", "&#39;", $v );
				$v = trim ( $v, "\\" );
			}
			$result [$k] = $v;
		}
		return $result;
	}
	function CreateImage($size, $source, $dest, $border = 0) {
		static $gd_version_number = null;
		if ($gd_version_number === null) {
			ob_start ();
			phpinfo ( 8 );
			$module_info = ob_get_contents ();
			ob_end_clean ();
			if (preg_match ( "/\bgd\s+version\b[^\d\n\r]+?([\d\.]+)/i", $module_info, $matches )) {
				$gd_version_number = $matches [1];
			}
		}
		if ($gd_version_number) {
			$sourcedate = 0;
			$destdate = 0;
			if (file_exists ( $dest )) {
				clearstatcache ();
				$sourceinfo = stat ( $source );
				$destinfo = stat ( $dest );
				$sourcedate = $sourceinfo [10];
				$destdate = $destinfo [10];
			}
			if (! file_exists ( "$dest" ) or ($sourcedate > $destdate)) {
				$imgsize = GetImageSize ( $source );
				$width = $imgsize [0];
				$height = $imgsize [1];
				$new_width = $size;
				$new_height = ceil ( $size * $height / $width );
				
				$ext = strtolower ( end ( explode ( '.', $source ) ) );
				switch ($ext) {
					case 'jpg' :
					case 'jpeg' :
						$im = @ImageCreateFromJPEG ( $source );
						break;
					case 'gif' :
						$im = @ImageCreateFromGIF ( $source );
						break;
					case 'png' :
						$im = @ImageCreateFromPNG ( $source );
						break;
				}
				if ($im && $gd_version_number >= 2) {
					$new_im = @ImageCreateTrueColor ( $new_width, $new_height );
				}
				if ($im && $gd_version_number < 2) {
					$new_im = @ImageCreate ( $new_width, $new_height );
				}
				if ($new_im) {
					ImageCopyResized ( $new_im, $im, 0, 0, 0, 0, $new_width, $new_height, ImageSX ( $im ), ImageSY ( $im ) );
					switch ($ext) {
						case 'jpg' :
						case 'jpeg' :
							ImageJPEG ( $new_im, $dest, 90 );
							break;
						case 'gif' :
							imageGIF ( $new_im, $dest );
							break;
						case 'png' :
							imagePNG ( $new_im, $dest );
							break;
					}
					ImageDestroy ( $new_im );
				}
			}
		}
	}
	function watermark($filename, $filedest = "") {
		$POSITION = $site->config ['watermark_pos'];
		$LEVEL = $site->config ['watermark_level'];
		if (! $filedest) {
			$filedest = $filename;
		}
		$watermarkimage = $this->path . "upload/image/wt.png";
		if (! function_exists ( 'imagecopymerge' ) || ! file_exists ( $watermarkimage )) {
			return;
		}
		$lst = GetImageSize ( $filename );
		$image_width = $lst [0];
		$image_height = $lst [1];
		$image_format = $lst [2];
		if ($image_format == 2) {
			$old_image = imagecreatefromjpeg ( $filename );
		} else if ($image_format == 3) {
			$old_image = imagecreatefrompng ( $filename );
		} else {
			return;
		}
		$lst2 = GetImageSize ( $watermarkimage );
		$image2_width = $lst2 [0];
		$image2_height = $lst2 [1];
		$image2_format = $lst2 [2];
		if ($image2_format == 2 && function_exists ( 'imagecreatefromjpeg' )) {
			$wt_image = imagecreatefromjpeg ( $watermarkimage );
		} elseif ($image2_format == 3 && function_exists ( 'imagecreatefrompng' )) {
			$wt_image = imagecreatefrompng ( $watermarkimage );
		}
		if (! $wt_image) {
			return;
		}
		$wt_y = "10";
		$wt_x = $image_width - $image2_width - 10;
		if ($POSITION == 1) {
			$wt_y = ( int ) ($image_height / 2 - $image2_height / 2);
			$wt_x = ( int ) ($image_width / 2 - $image2_width / 2);
		}
		if ($POSITION == 2) {
			$wt_y = $image_height - $image2_height - 10;
			$wt_x = $image_width - $image2_width - 10;
		}
		imagecopymerge ( $old_image, $wt_image, $wt_x, $wt_y, 0, 0, $image2_width, $image2_height, $LEVEL );
		if ($image_format == 2) {
			imageJpeg ( $old_image, $filedest );
		}
		if ($image_format == 3) {
			imagePng ( $old_image, $filedest );
		}
		imageDestroy ( $old_image );
		imageDestroy ( $wt_image );
	}
	function resizeimage($max_width, $im) {
		if (! $im) {
			return array ();
		}
		$image_details = @getimagesize ( "$im" );
		if (! $image_details) {
			return array ();
		}
		$imagesize_x = $image_details [0];
		$imagesize_y = $image_details [1];
		$thumb_width = $max_width;
		$thumb_height = ceil ( $max_width * $imagesize_y / $imagesize_x );
		if ($imagesize_x < $max_width) {
			$thumb_width = $imagesize_x;
			$thumb_height = $imagesize_y;
		}
		return array ($thumb_width, $thumb_height );
	}
	function upload_image($options = array( 'dest_folder' => "image", 'max_width' => 0, 'max_height' => 0, 'create_thumb' => true)) {
		global $_FILES;
		$file = $_FILES [$options['input']] ['tmp_name'];
		$file_name = $_FILES [$options['input']] ['name'];
		$file_size = $_FILES [$options['input']] ['size'];
		$image = '';
		if ($file_name) {
			// VALIDATE IMAGE EXTENSION, IMAGE SIZE
			$file_ext = strtolower ( end ( explode ( '.', $file_name ) ) );
			if (! $options['max_size'])
				$options['max_size'] = $this->upload_max_size;
			if (! in_array ( $file_ext, $options['extensions'] )) {
				$error = $file_ext . " " . $this->lang ['err_image_not_supported'];
			} else if ($options['max_size'] > 0 && $file_size > $options['max_size']) {
				$error = $this->lang ['err_image_max_size'];
			} else {
				$file_name = $this->prepare_file_name ( $file_name );
				// MOVE FILE TO "tmp" DIRECTORY
				$tmpfilename = $this->path . "upload/image/tmp/$file_name";
				if (! move_uploaded_file ( $file, $tmpfilename )) {
					$error = $this->lang ['err_image_upload_fail'];
				} else {
					@chmod ( $tmpfilename, 0644 );
					// VALIDATE BY MIME TYPE
					$size = @getimagesize ( $tmpfilename );
					// IF getimagesize() DOES NOT RECOGNIZE FILE AS AN IMAGE DELETE FILE
					if (! $size) {
						$error = $size ['mime'] . $this->lang ['err_image_not_recognized'];
					} // VALIDATE BY MAX WIDTH || MAX HEIGHT
					else if ($options['max_width'] > 0 && $size [0] > $options['max_width']) {
						$error = $this->lang ['err_image_max_width'];
						@unlink ( $tmpfilename );
					} else if ($options['max_height'] > 0 && $size [1] > $options['max_height']) {
						$error = $this->lang ['err_image_max_height'];
						@unlink ( $tmpfilename );
					} else {
						// VALIDATE BY FILE CONTENTS
						$fcontents = file_get_contents ( $tmpfilename );
						$carray = array ("html", "javascript", "vbscript", "alert", "onmouseover", "onclick", "onload", "onsubmit" );
						foreach ( $carray as $fch ) {
							if (strstr ( $fcontents, $fch )) {
								$error = $this->lang ['err_image_not_recognized'];
								@unlink ( $tmpfilename );
							}
						}
						if (preg_match ( "#script(.+?)/script#ies", $fcontents )) {
							$error = $this->lang ['err_image_not_recognized'];
							@unlink ( $tmpfilename );
						}
					}
				}
			}
			if (! $error) {
				$image = "dab" . time() . "_" . rand ( 111, 999 ) . "_" . substr ( $file_name, 0, - strlen ( $file_ext ) - 1 ) . "." . $file_ext;
				// MOVE FILE FROM "tmp" DIRECTORY TO DESTINATION DIRECTORY
				@rename ( $tmpfilename, $this->path . "upload/".$options['dest_folder']."/$image" );
				if (! is_file ( $this->path . "upload/".$options['dest_folder']."/$image" )) {
					$error = $this->lang ['err_image_upload_fail1'];
				} else if ($options['create_thumb'] == true) {
					if ($file_ext == 'jpg' || 'jpeg' || 'gif' || 'png') {
						echo 1;
						/*$this->CreateImage ( 200, $this->path . "upload/".$options['dest_folder']."/$image", $this->path . "upload/".$options['dest_folder']."/t_200_$image" );
						$this->CreateImage ( 400, $this->path . "upload/".$options['dest_folder']."/$image", $this->path . "upload/".$options['dest_folder']."/t_400_$image" );*/
					}
				}
			}
		}
		return array ($image, $error );
	}
	function upload_file($options = array('dest_folder' => "file")) {
		global $_FILES;
		$file = $_FILES [$options['input']] ['tmp_name'];
		$file_name = $_FILES [$options['input']] ['name'];
		$file_size = $_FILES [$options['input']] ['size'];
		$real_file = '';
		if ($file_name) {
			// VALIDATE FILE EXTENSION, FILE SIZE
			$file_ext = strtolower ( end ( explode ( '.', $file_name ) ) );
			if (! $options['max_size'])
				$options['max_size'] = $this->upload_max_size;
			if (! in_array ( $file_ext, $options['extensions'] )) {
				$error = $this->lang ['err_file_not_supported'];
			} else if ($options['max_size'] > 0 && $file_size > $options['max_size']) {
				$error = $this->lang ['err_file_max_size'];
			} else {
				$file_name = $this->prepare_file_name ( $file_name );
				$real_file = "dab" . time() . "_" . rand ( 111, 999 ) . "_" . substr ( $file_name, 0, - strlen ( $file_ext ) - 1 ) . "." . $file_ext;
				if (! move_uploaded_file ( $file, $this->path . "upload/".$options['dest_folder']."/$real_file" )) {
					$error = $this->lang ['err_file_upload_fail'];
				} else {
					@chmod ( $this->path . "upload/".$options['dest_folder']."/" . $real_file, 0644 );
				}
			}
		}
		return array ($real_file, $error );
	}
	function download_file($file) {
		if ($file) {
			$real_file = $this->path . "upload/" . $file;
			if (! is_file ( $real_file ) || connection_status () != 0) {
				$error = $this->lang ['err_file_download_fail'] ;
				print $error;
				exit ();
			}
			@set_time_limit ( 0 );
			$name = basename ( $file );
			if (strstr ( $_SERVER ['HTTP_USER_AGENT'], "MSIE" )) {
				$name = preg_replace ( '/\./', '%2e', $name, substr_count ( $name, '.' ) - 1 );
			}
			header ( "Cache-Control: " );
			header ( "Pragma: " );
			header ( "Content-Type: application/octet-stream" );
			header ( "Content-Length: " . ( string ) (filesize ( $real_file )) );
			header ( 'Content-Disposition: attachment; filename="' . $name . '"' );
			header ( "Content-Transfer-Encoding: binary\n" );
			$h = fopen ( $real_file, 'rb' );
			if ($h) {
				while ( (! feof ( $h )) && (connection_status () == 0) ) {
					print (fread ( $h, 1024 * 8 )) ;
					flush ();
				}
				fclose ( $h );
			}
			exit ();
		}
	}
	function prepare_file_name($file) {
		// REPLACE ILLEGAL SUB-EXTENSIONS
		$com_types = array ('com', 'exe', 'bat', 'scr', 'pif', 'asp', 'cgi', 'pl', 'php' );
		foreach ( $com_types as $bad ) {
			$file = str_replace ( ".$bad", "_$bad", $file );
		}
		// REPLACE ILLEGAL CHARACTERS
		return preg_replace ( '/[^\w.-]/', '', urlencode ( $file ) );
	}
    
	private function download() {
		$this->download_file ( 'file/' . $this->input ['file'] );
		exit ();
	}
	private function upload_all() {
		if ($this->input ['jx']) {
			include ('class_xml.php');
			$xml = new dab_XML_Builder ( 'text/xml', 'utf-8' );
			if ($this->input ['inputfile']) {
				if ($this->input ['type'] == 'image') {
					$file = $this->upload_image ( array( 'input' =>$this->input ['inputfile'], 'extensions' => array('jpg', 'png', 'gif', 'jpeg'), 'dest_folder' => "image", 'create_thumb' => true ));
				} else {
					$file = $this->upload_file ( array( 'input' => $this->input ['inputfile'], 'extensions' => array('docx', 'swf'), 'dest_folder' => "file") );
				}
				$xml->add_group ( 'response' );
				$xml->add_group ( 'file' );
				$xml->add_tag ( 'name', $file [0] );
				$xml->add_tag ( 'error', $file [1] );
				$xml->close_group ();
				$xml->close_group ();
				$f = $this->prepare_file_name ( $_FILES [$this->input ['inputfile']] ['name'] );
				$_SESSION [$f] = $xml->return_xml ();
			}else{
				$f = $this->prepare_file_name ( $this->input ['filename'] );
				if ($_SESSION [$f]) {
					$xml->send_content_type_header ();
                    
                    // Newly added 
                    $_SESSION['myImages'][] = $_SESSION [$f];
                    print $_SESSION [$f];
					unset ( $_SESSION [$f] );
				}
			}
		}
	}
	private function unload() {
		if ($this->input ['type'] == 'image') {
			$this->delete_images ( $this->input ['file'] );
			mysql_query ( "DELETE FROM global_images WHERE module = '".$this->module."' AND (identry = '{$this->input['identry']}' OR name = '{$this->input['file']}') LIMIT 1" );
		} else {
			$this->delete_files ( $this->input ['file'] );
			mysql_query ( "DELETE FROM global_files WHERE module = '".$this->module."' AND (identry = '{$this->input['identry']}' OR name = '{$this->input['file']}') LIMIT 1" );
		}
	}
	private function delete_images($file) {
		$images = array ($file, "t_200_" . $file, "t_400_" . $file, "wt_" . $file );
		foreach ( $images as $v ) {
			$file = $this->path . "upload/image/" . $v;
			if (is_file ( $file )) {
				unlink ( $file );
			}
		}
	}
	private function delete_files($file) {
		$file = $this->path . "upload/file/" . $file;
		if (is_file ( $file )) {
			unlink ( $file );
		}
	}
}
?>