<?php
/**
 * PageNav Class
 * @author Original by Kenny Chen <http://kennychen.idv.tw/>
 * @version 0.1.0
 =========================================================================================
 [ Using Demo ]
 =========================================================================================
 $totalNum = 101;
 $page = isset ( $_GET ['page'] ) ? $_GET ['page'] : 1;
 $perPage = 10;
 $url = $_SERVER['PHP_SELF'];
 $length = 5;
 $class = 'pages';

 $pagerBox = new PagerBox ( );  
 echo $pagerBox->getPager ( $totalNum, $page, $url, $perPage, $length, $class, TRUE );  
 =========================================================================================
 */
class PageNav {
	var $htmlText;
	var $cssPath;
	
	const STR_PAGENUM = 'Page';
	const STR_FIRST = '1st';
	const STR_PRE = '&laquo;';
	const STR_NEXT = '&raquo;';
	const STR_LAST = 'Last';
	
	/** 
	 * @param int $page
	 * @param int $totalNum
	 * @param int $perPage
	 * @param string $url
	 * @param int $length
	 * @param string $class
	 * @param bool $iscss
	 * @return html 
	 */
	
	public function PageNav($totalNum, $page, $url, $perPage, $length = '5', $class = '', $default = FALSE) {
		$pageNum = ceil ( $totalNum / $perPage );
		$currentNum = ($page) ? $page : 1;
		$html = '';
		//$html .= '<div class="' . $class . '">';
		//$html .= '<ul class="page_nav">';
		//if($page>2)$html .= $this->getFirstHTML ( $page, $url );  
		if ($page > 1)
			$html .= $this->getPreHTML ( $page, $url );
		$html .= $this->getPages ( $page, $url, $currentNum, $length, $pageNum );
		if ($page != $pageNum)
			$html .= $this->getNextHTML ( $page, $url, $pageNum );
		
		if($page<$pageNum-1)$html .= $this->getLastHTML ( $page, $url, $pageNum );  
		$html .= ' ';  
		//$html .= '<span  class="pages">'.self::STR_PAGENUM.'&#65306;'.$page.' of '.$pageNum.'</span>';
		//$html .= '</ul>';
		//$html .= '</div>';
		$this->html = $html;
	}
	
	public function render() {
		echo $this->html;
	}
	/** 
	 * &#29554;&#21462;&#26368;&#21069;&#38913;HTML 
	 * 
	 * @param int $page 
	 * @param string $url 
	 * @return html 
	 */
	private function getFirstHTML($page, $url) {
		$html = '';
		if ($page == 1 || ! $page) {
			$html .= $this->getHTML ( self::STR_FIRST );
		} else {
			$html .= $this->getHTML ( self::STR_FIRST, TRUE, $this->getURL ( $url, 1 ) );
		}
		return $html;
	}
	/** 
	 * &#29554;&#21462;&#19978;&#19968;&#38913;HTML 
	 * 
	 * @param int $page 
	 * @param string $url 
	 * @return html 
	 */
	private function getPreHTML($page, $url) {
		$html = '';
		if (($page - 1) == 0) {
			$html .= $this->getHTML ( self::STR_PRE );
		} else {
			$html .= $this->getHTML ( self::STR_PRE, TRUE, $this->getURL ( $url, ($page - 1) ) );
		}
		return $html;
	}
	
	/** 
	 * &#29554;&#21462;&#38913;HTML 
	 * 
	 * @param int $page 
	 * @param string $url 
	 * @param int $currentNum 
	 * @param int $pageLength 
	 * @param int $pageNum 
	 * @return html 
	 */
	private function getPages($page, $url, $currentNum, $length, $pageNum) {
		$html = '';
		$start = ceil ( $page / $length );
		$start = ($start - 1) * $length + 1;
		$end = $start + $length - 1;
		$end = ($end > $pageNum) ? $pageNum : $end;
		
		for($i = $start; $i <= $end; $i ++) {
			if ($currentNum == $i) {
				$html .= $this->getHTML ( $i );
				continue;
			}
			$html .= $this->getHTML ( $i, TRUE, $this->getURL ( $url, $i ) );
		}
		$u = $_SERVER ['PHP_SELF'];
		$html .= "";
		for($i = $start; $i <= $end; $i ++) {
			$html .= ""; // ( $i, $this->getURL ( $url, $i ) );  
		}
		$html .= "";
		return $html;
	}
	
	/** 
	 * GetHTML [ Next Page ]
	 * 
	 * @param int $page 
	 * @param string $url 
	 * @param int $pageNum 
	 * @return html 
	 */
	private function getNextHTML($page, $url, $pageNum) {
		$html = '';
		if (($page - $pageNum) == 0) {
			$html .= $this->getHTML ( self::STR_NEXT );
		} else {
			$html .= $this->getHTML ( self::STR_NEXT, TRUE, $this->getURL ( $url, ($page + 1) ) );
		}
		return $html;
	}
	/** 
	 * GetHTML [ Last Page ]
	 * 
	 * @param int $page 
	 * @param string $url 
	 * @param int $pageNum 
	 * @return html 
	 */
	private function getLastHTML($page, $url, $pageNum) {
		$html = '';
		if ($page == $pageNum) {
			$html .= $this->getHTML ( self::STR_LAST );
		} else {
			$html .= $this->getHTML ( self::STR_LAST, TRUE, $this->getURL ( $url, $pageNum ) );
		}
		return $html;
	}
	/** 
	 * &#29554;&#21462;&#20998;&#38913;HTML 
	 * 
	 * @param string $text 
	 * @param bool $isUrl 
	 * @param string $url 
	 * @param string $class 
	 * @return html 
	 */
	private function getHTML($text, $isUrl = FALSE, $url = '', $class = '') {
		
		if ($isUrl) {
			return $this->getAHtml ( $text, $url );
		}
		return $this->getSpanHtml ( $text, $url );
	}
	/** 
	 * Creat URL 
	 * 
	 * @param string $url 
	 * @param int $page 
	 * @return url 
	 */
	private function getURL($url, $page) {
        if(@$_GET['date']!=''){
return $url . '-date='.$_GET['date'].'&page=' . $page;
        }elseif(@$_GET['cat']!=''){
return $url . '-cat='.$_GET['cat'].'&page=' . $page;
        }else{
return $url . '_' . $page;
}
    }
	/** 
	 * Creat <span>
	 * 
	 * @param string $text 
	 * @param string $class 
	 * @return html 
	 */
	private function getSpanHtml($text,$url) {
		return ' <li class="active"><a href="' . $url . '">' . $text . '</a></li>';
	}
	/** 
	 * Creat <a>
	 * 
	 * @param string $text 
	 * @param string $url 
	 * @return html 
	 */
	private function getAHtml($text, $url) {
		return ' <li><a href="' . $url . '">' . $text . '</a></li>';
	}
	/** 
	 * @return css 
	 */
	private function getDefaultCss() {
		$css = '<style type="text/css">';
		$css .= '.pages {margin:15px auto 0 auto;padding-right:40px;text-align:right;}  
			   .pages a, .pages span {display:inline-block;*display:inline;zoom:1;padding:0px 6px;height:21px;line-height:21px;font-size:12px;font-weight:100;background:#F5F8FF;overflow:hidden;}  
			   .pages a {border:1px solid #D8E0ED;}  
			   .pages span {border:1px solid #dddddd;background:#FFFFFF;color:#999999;}  
			   a{text-decoration:none;color:#666666;}  
			   a:hover{text-decoration:underline;color:#0657b2;}';
		$css .= '</style>';
		return $css;
	}

}
?>  
